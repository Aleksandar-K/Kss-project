
let router = require('express').Router();
router.get('/', function (req, res) {
});
var contactController = require('./contactController');
router.route('/contacts')
    .get(contactController.index)
    .post(contactController.new);

router.route('/contacts/create')
    .get(contactController.create);

router.route('/contacts/:contact_id')
    .get(contactController.view)
    .patch(contactController.update)
    .put(contactController.update)
    .delete(contactController.delete);

module.exports = router;
